

$('.last__news_slider').slick({
    dots: false,
    infinite: false,
    speed: 300,
    nextArrow:'<i class="icon-Rarrowright last__news_arrow_right"></i>',
	prevArrow: '<i class="icon-Rarrowleft last__news_arrow_left"></i>',
    slidesToShow: 4,
    slidesToScroll: 4,
    responsive: [
      {
        breakpoint: 1200,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          infinite: false,
          dots: false
        }
      },
      {
        breakpoint: 991,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2
        }
      },
      {
        breakpoint: 555,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
    ]
  });


  

$('.project__slider').slick({
  dots: false,
  infinite: false,
  speed: 300,
  nextArrow:'<i class="icon-Rarrowright last__news_arrow_right"></i>',
  prevArrow: '<i class="icon-Rarrowleft last__news_arrow_left"></i>',
  slidesToShow: 4,
  slidesToScroll: 4,
  responsive: [
    {
      breakpoint: 1200,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: false,
        dots: false
      }
    },
    {
      breakpoint: 991,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 555,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
  ]
});

$('.header__navigation_ul').slick({
  dots: false,
  infinite: true,
  autoplay: true,
  autoplaySpeed: 2000,
  arrows:false,
  slidesToShow: 7,
  variableWidth: true,
  responsive: [
    {
      breakpoint: 1200,
      settings: {
        arrows:false,
        infinite: true,
        dots: false
      }
    },
    {
      breakpoint: 991,
      settings: {
        arrows:false,
      }
    },
    {
      breakpoint: 555,
      settings: {
        arrows:false,
      }
    }
  ]
});



$('.cart_page_slider').slick({
  dots: false,
  infinite: false,
  speed: 300,
  nextArrow:'<i class="icon-Rarrowright carts_page_arrow_right"></i>',
prevArrow: '<i class="icon-Rarrowleft carts_page_arrow_left"></i>',
  slidesToShow: 3,
  slidesToScroll: 1,
  responsive: [
    {
      breakpoint: 1200,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1,
        infinite: false,
        dots: false
      }
    },
    {
      breakpoint: 991,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 555,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
  ]
});


$('.history__photogallery_block').slick({
  dots: false,
  infinite: false,
  speed: 300,
  nextArrow:'<i class="icon-Rarrowright history_page_arrow_right"></i>',
  prevArrow: '<i class="icon-Rarrowleft history_page_arrow_left"></i>',
  slidesToShow: 3,
  slidesToScroll: 1,
  responsive: [
    {
      breakpoint: 1200,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1,
        infinite: false,
        dots: false
      }
    },
    {
      breakpoint: 991,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 555,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
  ]
});


const search = document.querySelector('.call__input');
const exitSearch = document.querySelector('.search__exit');
const searchHeader = document.querySelector('.search__header');

if(search) {
  search.addEventListener('click', function() {
    searchHeader.classList.toggle('active')
  })
};

if(exitSearch) {
  exitSearch.addEventListener('click', function() {
    searchHeader.classList.remove('active')
  })
};

/* 

$("#languageSelect").mouseover(function(){
  $(this)[0].size=$(this).find("option").length;
});
$("#languageSelect").click(function(){
   $(this)[0].size=0;
}); */

const burger = document.querySelector('.burger');
const headerExit = document.querySelector('.header__nav_exit');
const headerNav = document.querySelector('.header__nav');
const bodyy = document.querySelector('body')

if(burger) {
  burger.addEventListener('click', function() {
    headerNav.classList.toggle('active');
    bodyy.classList.toggle('active');
  })
};

if(headerExit) {
  headerExit.addEventListener('click', function() {
    headerNav.classList.remove('active')
    bodyy.classList.remove('active');
  })
};





let btns = document.getElementsByClassName("header__navigation_links");
for (let i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function() {
    let current = document.getElementsByClassName("active");


    if (current.length > 0) {
      current[0].className = current[0].className.replace(" active", "");
    }

    this.className += " active";
  });
};







// Требуется jQuery


// Scroll active

$(window).scroll(function () {
    var scrollDistance = $(window).scrollTop();

    $('section').each(function (i) {
        if ($(this).position().top - 51 <= scrollDistance) {
            $('a[href*="#"]:not([href="#"]).active').removeClass('active');
            $('a').eq(i).addClass('active');  
        }
    });

}).scroll();

//Scroll to anchor

$(function () {
    $('a[href*="#"]:not([href="#"])').click(function () {
        //        Если не использовать scroll active

              /*   $('a').each(function () {
                   $(this).removeClass('active');
                })
                $(this).addClass('active'); */
                
        if (location.pathname.replace(/^\//, '') === this.pathname.replace(/^\//, '') && location.hostname === this.hostname) {
            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
            if (target.length) {
                $('html, body').animate({
                    scrollTop: target.offset().top - 50
                }, 500);
                return false;
            }
        }
    });
});
  

let right = document.getElementById("rightnavigation");
let stop = (right.offsetTop - 200);

window.onscroll = function (e) {
    let scrollTop = (window.pageYOffset !== undefined) ? window.pageYOffset : (document.documentElement || document.body.parentNode || document.body).scrollTop;
    console.log(scrollTop, right.offsetTop);
    // right.offsetTop;

    if (scrollTop >= stop) {
      right.className = 'stick';
    } else {
      right.className = '';
    }

};





/* активный при скролле  */




